//
//  SecondViewController.swift
//  UIPageViewController Post
//
//  Created by medidi vv satyanarayana murty on 27/12/16.
//  Copyright © 2016 Seven Even. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet var secondWebView: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        let url = NSURL(string: "https://www.wikipedia.org")
        let urlRequest = NSURLRequest(url: url! as URL)
        secondWebView.loadRequest(urlRequest as URLRequest)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    
}
