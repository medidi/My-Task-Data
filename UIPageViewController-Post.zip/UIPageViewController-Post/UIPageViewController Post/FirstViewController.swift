//
//  FirstViewController.swift
//  UIPageViewController Post
//
//  Created by medidi vv satyanarayana murty on 27/12/16.
//  Copyright © 2016 Seven Even. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController
{

    @IBOutlet var firstWebView: UIWebView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

        let url = NSURL(string: "https://www.google.co.in")
        let urlRequest = NSURLRequest(url: url! as URL)
        firstWebView.loadRequest(urlRequest as URLRequest)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
}
