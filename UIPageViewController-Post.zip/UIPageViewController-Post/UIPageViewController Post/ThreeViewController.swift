//
//  ThreeViewController.swift
//  UIPageViewController Post
//
//  Created by medidi vv satyanarayana murty on 27/12/16.
//  Copyright © 2016 Seven Even. All rights reserved.
//

import UIKit

class ThreeViewController: UIViewController {

    @IBOutlet var threeWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let url = NSURL(string: "https://mail.exilant.com/#1")
        let urlRequest = NSURLRequest(url: url! as URL)
        threeWebView.loadRequest(urlRequest as URLRequest)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

   

}
