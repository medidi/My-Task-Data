//
//  ScaledVisibleCellsCollectionView.h
//  ScaledVisibleCellsCollectionView
//
//  Created by Mai Ikeda on 2015/08/22.
//  Copyright (c) 2015年 mai_ikeda. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ScaledVisibleCellsCollectionView.
FOUNDATION_EXPORT double ScaledVisibleCellsCollectionViewVersionNumber;

//! Project version string for ScaledVisibleCellsCollectionView.
FOUNDATION_EXPORT const unsigned char ScaledVisibleCellsCollectionViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ScaledVisibleCellsCollectionView/PublicHeader.h>


