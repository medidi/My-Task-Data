//
//  AppDelegate.swift
//  UserNotification
//
//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate,NSUserNotificationCenterDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
         NSUserNotificationCenter.default.delegate = self
    }

    

    func userNotificationCenter(_ center: NSUserNotificationCenter, shouldPresent notification: NSUserNotification) -> Bool {
        // return true to always display the User Notification
        
        return true
        
    }
    
    
    func userNotificationCenter(_ center: NSUserNotificationCenter, didActivate notification: NSUserNotification) {
        
        // Get the path from the userInfo dictionary of the User Notification
        let path = notification.userInfo!["path"] as! String
        
        // Open the file at the path
        NSWorkspace.shared().openFile(path)
        
    }
    
    
    func applicationWillTerminate(_ aNotification: Notification) {
        
    }
    
}





    

    


    

