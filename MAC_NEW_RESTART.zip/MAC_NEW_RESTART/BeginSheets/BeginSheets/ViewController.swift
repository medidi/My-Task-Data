//
//  ViewController.swift
//  BeginSheets
//
//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet var click: NSButton!
    @IBOutlet var label: NSTextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()

       label.isHidden = true
    }

    @IBAction func click(_ sender: AnyObject)
    {
               label.isHidden = false
        
    }
    


}

