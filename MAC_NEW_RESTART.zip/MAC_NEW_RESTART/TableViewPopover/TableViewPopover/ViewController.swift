//
//  ViewController.swift
//  TableViewPopover

//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

class ViewController: NSViewController
{
    //MARK:- Explicit Properties
    
    var secondview:SecondViewController?
    
    //MARK:- viewDidLoad
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }

    //MARK:- Alert
    
    @IBAction func alert(_ sender: AnyObject) {
        
        print("Alert")
//        secondview = SecondViewController(windowNibName: "SecondViewController")
//        secondview?.window?.beginSheet((secondview?.window!)!, completionHandler: nil)
        secondview?.showWindow(self.secondview)
        
    }
    //MARK:- Popover
    
    @IBAction func popover(_ sender: AnyObject) {
        print("Popover")

    }
    //MARK:- Sheet
    @IBAction func sheet(_ sender: AnyObject) {
        print("Sheet")

    }
}

