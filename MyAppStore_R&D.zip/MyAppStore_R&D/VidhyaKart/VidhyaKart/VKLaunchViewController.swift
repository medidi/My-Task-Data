//
//  VKLaunchViewController.swift
//  VidhyaKart
//
//  Created by medidi vv satyanarayana murty on 16/01/17.
//  Copyright © 2017 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import UIKit

class VKLaunchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       let appDel = UIApplication.shared.delegate as! AppDelegate
        
        
        appDel.window = UIWindow(frame: UIScreen.main.bounds)
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        appDel.window?.rootViewController = storyBoard.instantiateViewController(withIdentifier: "VKLoginVC") as! VKLoginViewController
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
