//
//  ViewController.swift
//  VidhyaKart
//
//  Created by medidi vv satyanarayana murty on 16/01/17.
//  Copyright © 2017 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import UIKit

class VKLoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

