//: Playground - noun: a place where people can play

import UIKit

//let srr = [2,4,7,9,11,15,22,54]
//for i in srr{
//    if( i == 15){
//        print(i)
//    }
//}

let arr = [2,4,7,9,11,15,22,54]
let length = arr.count
var low = 0
var high = length
var mid = length/2
while low != high{
    
    if arr[mid] == 15{
        print("found")
    }else if(arr[mid]<15){
        low = mid+1
    }else{
        high = mid
    }
}

