package satyam.medidi;


	import java.util.HashMap;
	import java.util.Scanner;

	public class syno {
		public static void main(String[] args) {
			HashMap<String, String[]> synonomes= new HashMap<String, String[]>();
			synonomes.put("Beautiful", new String[]{"Attractive","Pretty","Lovely","Stunning"});
			synonomes.put("Fair", new String[]{"Just","Objective","Impartial","Unbiased"});
			synonomes.put("Funny", new String[]{"Humorous","Comical","Hilarious","Hysterical"});
			synonomes.put("Happy", new String[]{"Content","Joyful","Mirthful","Upbeat"});
			
			// I have taken from user using scanner also we can read from command line argument
			// String syno = args[0];
			Scanner acan = new Scanner(System.in);
			System.out.println("Enter Your Word like Ex:Beautiful,Fair,Funny,Happy");     
			
			String syno = acan.next();
			String[] names = synonomes.get(syno);
		
			for(String temp: names)
			{
				System.out.println(temp);
			}
			
		}
		
	}
	

	
